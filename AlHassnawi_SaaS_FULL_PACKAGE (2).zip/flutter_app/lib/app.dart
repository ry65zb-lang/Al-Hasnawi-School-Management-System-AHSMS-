import 'package:flutter/material.dart';
import 'routes/app_routes.dart';

class SchoolApp extends StatelessWidget {
  const SchoolApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Al-Hassnawi SaaS',
      initialRoute: '/dashboard',
      routes: AppRoutes.routes,
    );
  }
}
