class Session {
  static String? userId;
  static String? schoolId;
  static String? role;
}
