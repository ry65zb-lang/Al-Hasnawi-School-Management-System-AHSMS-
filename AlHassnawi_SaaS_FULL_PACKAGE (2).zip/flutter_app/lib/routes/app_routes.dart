import 'package:flutter/material.dart';

class AppRoutes {
  static Map<String, WidgetBuilder> routes = {
    '/dashboard': (context) => const Scaffold(
      body: Center(child: Text('Dashboard')),
    ),
  };
}
