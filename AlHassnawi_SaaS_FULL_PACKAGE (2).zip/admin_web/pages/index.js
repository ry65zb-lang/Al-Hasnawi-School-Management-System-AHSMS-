export default function Home() {
  return <h1>Al-Hassnawi SaaS Admin Panel</h1>;
}
